package catalogo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CatalagoApplication {

	public static void main(String[] args) {
		SpringApplication.run(CatalagoApplication.class, args);
	}

}
