package catalogo.dto;

import lombok.Data;

@Data
public class CatalogoDto {
    private String tipoPublicacion;
    private Object datosPublicacion;
}