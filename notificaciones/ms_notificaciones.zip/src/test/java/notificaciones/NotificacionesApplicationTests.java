package notificaciones;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NotificacionesApplicationTests {

	@Test
	void contextLoads() {
	}

}
